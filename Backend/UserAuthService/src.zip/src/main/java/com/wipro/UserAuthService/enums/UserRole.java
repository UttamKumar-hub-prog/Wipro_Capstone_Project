package com.wipro.UserAuthService.enums;

public enum UserRole {
	
	ADMIN,USER 

}
